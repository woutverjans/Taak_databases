package be.kuleuven.dbproject.controllers;

public interface MyController {
    public void setData(Object data);
}
